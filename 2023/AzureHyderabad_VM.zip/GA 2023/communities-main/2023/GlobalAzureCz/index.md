﻿# Global Azure Prague 2023

![Global Azure Prague](global-azure-prague.png)

Please visit [https://globalazure.cz](https://globalazure.cz).

## Organizers
* David Gešvindr (WUG CZ)
* Robert Haken (HAVIT)
* Tomáš Herceg (Update Conference)
(in alphabetical order)
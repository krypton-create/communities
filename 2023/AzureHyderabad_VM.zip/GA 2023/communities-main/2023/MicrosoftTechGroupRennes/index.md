**Bienvenue au Microsoft Tech Group Rennes**

Réseau créé dans le but d’animer une communauté rennaise d’utilisateurs Microsoft, le MTG (Microsoft Tech Group) est le prolongement de l'ancien MUG (Microsoft User Group), adoptant le branding national.
Nous organisons régulièrement des meetups sur différents thèmes, principalement .Net, Azure et Office 365. Les autres sujets Microsoft sont aussi les bienvenus !

Retrouvez toutes les informations concernant le Global Azure 2023 et nos activités plus généralement sur nos réseaux :
* [Meetup](https://www.meetup.com/fr-FR/MTG-Rennes)
[![Global Azure Bootcamp 2023 - Nigeria](mctnaija_logo.png "Global Azure 2023 - Nigeria")](https://www.meetup.com/mctnaija-techusergroup/)

* [YouTube Channel](https://www.youtube.com/@mctnaija-techusergroup1837/videos)
* [FB Page](https://web.facebook.com/groups/572914577044941)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

OLuwaseyi OLuwawumiju [Microsoft MVP/MCT](https://mvp.microsoft.com/en-us/PublicProfile/5002974)

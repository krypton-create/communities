# Global Azure 2023 - Kathmandu

[![Global Azure 2023 - Kathmandu](global-azure-kathmandu-nepal.png "Global Azure Bootcamp 2023 - Kathmandu registration (TBD)")](https://www.facebook.com/NepalCloudPro)

We are calling all Azure enthusiasts to come and join us, where we share our expertise and experience.
-------------------------------------------------

Hosted by [Nepal Cloud Professionals and techWebinarNepal](https://www.facebook.com/NepalCloudPro).

All our events are free for all attendees. We are committed to your privacy, and your data will never be shared.
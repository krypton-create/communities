# Japan Azure User Group

![jazug logo][2]

## About

Japan Azure User Group is a Japanese user group formed on August 26, 2010 to learn, enjoy, and make the most of Microsoft Azure. 
Let's get together and make it happen!

## Event page

https://jazug.connpass.com/event/279068/

## Links
[Main website][0]
[Twitter][1]

[0]: https://r.jazug.jp/
[1]: https://twitter.com/hashtag/jazug
[2]: jazug.png


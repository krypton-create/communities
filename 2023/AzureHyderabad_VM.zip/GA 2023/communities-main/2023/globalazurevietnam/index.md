# Global Azure 2023 - Vietnam by [DEV Cafe](https://www.facebook.com/devcafevn)

[![Global Azure 2023 - Vietnam Logo](globalazurevietnam.png "Visit us here!")](https://devcafevn.github.io/globalazure2023/)

We are excited to host the Global Azure 2023 for developer community in Vietnam

This is an online event, all talks about Microsoft Azure!

You can find more information about the event on our website https://devcafevn.github.io/globalazure2023/

# Global Azure Istanbul

[![MSHOWTO logo](mshowto.png "Visit us here")](https://www.mshowto.org/)

Global Azure 2023 Istanbul is hosted by [MSHOWTO](https://www.mshowto.org/)

Session details, tickets/seat reservation will be available soon!

![Global Azure Istanbul](gaist2023.png)
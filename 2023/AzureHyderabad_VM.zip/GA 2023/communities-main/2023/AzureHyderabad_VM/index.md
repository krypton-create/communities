# Global Azure Bootcamp 2023 - ValueMomentum

[![ValueMomentumGlobalAzureBootcamp](ValueMomentumGlobalAzureBootcamp.png "Global Azure Bootcamp 2023 - ValueMomentum Registration")](https://www.valuemomentum.com/)

ValueMomentum is thrilled to announce the 6th iteration of the Global Azure event, the ‘Global Azure 2023’, following the successful organization of the previous Global Azure editions.
The event, to be held at our ValueMomentum Towers, Hyderabad office, is open to anyone who is interested in learning and gaining knowledge about Microsoft Azure-based technology stack. As part of this event, participants will also be able to learn about Microsoft Azure's cloud capabilities.

We have a line-up of interactive and experiential sessions in which participants will understand and visualize the full gamut of Microsoft Azure technologies. The event will feature a panel of speakers with rich and diverse experience in Microsoft technology stack. 


# MTG Azure DevOps Aix-en-Provence

https://www.meetup.com/fr-FR/meetup-azure-devops-aix-en-provence/

Ce groupe s'adresse à tous ceux qui souhaitent partager leur retour d'expérience de transition vers les Technologies Cloud de Microsoft Azure, et le passage en Mode Devops et les solutions associées : CI/CD, Containers, Micro Services ..
Manifesto de la communauté Azure & Devops User Group Aix en Provence
- Les sujets liés aux technologies Microsoft Azure et Devops sont strictement prioritaires par rapport aux autres technologies
- Nous comptons plus sur l'engagement des membres que sur le nombre
- La contribution des membres est recherchée autant que celle des experts extérieurs au groupe
- L'apprentissage collaboratif l'emporte sur l'autopromotion
- Les événements sont principalement gratuits (rares seront les événements payants, nous faisons notre possible pour les éviter)
- Respect et humilité l'emportent sur les compétences techniques de chacun
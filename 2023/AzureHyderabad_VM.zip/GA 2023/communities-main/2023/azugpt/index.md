# Global Azure Portugal by Azure User Group Portugal

[![Azure User Group Portugal](AZUGPT.png "Visit us here!")](https://www.globalazure.pt/)

Global Azure Portugal is a community event organized by the Azure User Group Portugal.
All around the world user groups and communities are sharing knowledge to professionals that want to learn more about Microsoft Azure and Cloud Computing!
On May 13, 2023, we will come together to once again bring the Global Azure event! The Azure User Group Portugal brings a one day world-class event on Microsoft Azure. Join us online and don't forget to use the social hashtags #GlobalAzurePT and #GlobalAzure!


The [Call for Speakers is open](https://sessionize.com/global-azure-portugal-2023/). Selection will happen on an ongoing basis. Don't wait to the last day to submit your sessions!!! 


Resume information:
* 📅May, 13 2023
* 🏠Microsoft Lisbon
* 🎫Get your FREE ticket - [https://www.globalazure.pt/](https://www.globalazure.pt/)
* 🎙️Call for speakers - [https://sessionize.com/global-azure-portugal-2023](https://sessionize.com/global-azure-portugal-2023/)
* 💶Sponsors - We are looking for sponsors. Reach out to the organization team at [https://www.meetup.com/Azure-User-Group-Portugal/](https://www.meetup.com/Azure-User-Group-Portugal/)

If you have any questions, feedback or thoughts, please reach out to the community organizers at:
* https://www.meetup.com/Azure-User-Group-Portugal/
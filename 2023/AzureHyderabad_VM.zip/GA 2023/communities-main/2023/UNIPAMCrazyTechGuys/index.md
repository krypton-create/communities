# Global Azure 2023 - UNIPAM

![](UNIPAMCrazyTechGuys.png)



Estamos de volta na UNIPAM para mais um Global Azure, este ano teremos um dia repleto de atividades! Estamos muito animados para receber vocês no [clique aqui para se inscrever](https://www.eventbrite.com.br/e/global-azure-patos-de-minas-tickets-615695370427)!

Vai ser demais!

No dia 13 de maio estaremos juntos com as comunidades no Global Azure 2023. Nosso evento será presencial com palestrantes no local e também de forma remota, mas não teremos transmissão ao vivo. Junte-se a nós para ter acesso a palestras e workshops que cobrirão os mais diversos tópicos sobre o universo do Azure, incluindo segurança, soluções de nuvem, inteligência artificial, IoT e muito mais. Com a presença de especialistas Microsoft e líderes da indústria, você terá acesso a insights e conhecimentos exclusivos para ajudá-lo a impulsionar sua carreira e expandir sua expertise em nuvem. 

Não perca a chance de participar deste evento único que promove o compartilhamento de conhecimento e o fortalecimento da comunidade de desenvolvedores e profissionais de nuvem em todo o mundo. 

Registre-se agora e participe do Global Azure 2023!

** Todas as incrições devem ser feitas somente pelo link: [clique aqui para se inscrever](https://www.eventbrite.com.br/e/global-azure-patos-de-minas-tickets-615695370427)!!


A grade de palestras será fornecida em breve, o evento será feito no modelo híbrido, presencialmente no Reactor de SP e online para quem não puder estar no local. 

Organizado por:  
Lara Ferreira [twitter](https://twitter.com/Lari_evef), Flávio Ferreira [twitter](https://twitter.com/flaviolucioqf)  e Jorge Maia [twitter](https://twitter.com/jorgemaia)



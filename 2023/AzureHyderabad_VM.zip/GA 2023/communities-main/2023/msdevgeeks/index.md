# Microsoft DEV Geeks

Visit our website at https://www.meetup.com/msdevgeeks/

![msdevgeeks](https://www.techmeet360.com/wp-content/uploads/2017/07/techmeet360-logo.png)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Alagunila Meganathan [Microsoft MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5002657) [@alagunilam](https://twitter.com/alagunilam)
* Kuppurasu Nagaraj [Azure MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5001934) [@kuppurasu360](https://twitter.com/kuppurasu360)

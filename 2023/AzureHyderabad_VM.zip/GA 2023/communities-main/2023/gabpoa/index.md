![alt text](https://github.com/digomatos/communities/blob/main/2023/gabpoa/gabpoa.png)

Global Azure Porto Alegre (GABPOA) is an event organized by the local community of MVPs from Porto Alegre and region.

An event that has several professionals with knowledge in Azure in Rio Grande do Sul.

The event is open to the entire community, regardless of the level of knowledge on the platform, we will have a day full of learning, come and be a part of it.


Other contact details available on https://gabpoa.azurewebsites.net

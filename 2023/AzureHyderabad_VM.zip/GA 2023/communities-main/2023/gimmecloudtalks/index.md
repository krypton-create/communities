## Welcome to Gimme Cloud Talks Global Azure 2023 Event ##

Gimme Cloud Talks is providing an opportunity for speakers to participate in Global Azure 2023 through our user group site.  

Events will be streamed live or pre-recorded for viewing during Global Azure 2023 on 11 May - 13 May, 2023.  

In partnership with Speaking Mentors (https://www.linkedin.com/groups/14192753/), first time speakers are welcome. All sessions will be posted on https://gimmecloudtalks.github.io and https://globalazure.net.

Call for Speakers is open at <https://sessionize.com/gimme-cloud-talks-global-azure-2023/>
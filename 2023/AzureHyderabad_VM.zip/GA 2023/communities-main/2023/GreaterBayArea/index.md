# Global Azure GBA

Join our Community: http://hdxu.cn/qvgNP

Welcome to Global Azure Bootcamp 2023!

This will be the first edition of Global Azure Bootcamp in GBA. After couple of years of virtual events during the COVID-19 pandemic, we are excited to be back in person. We look forward to the vibrant community members to join us on this fantastic day.

 
If you have any questions, feedback or thoughts, please reach out to the Community organizer:

* Geffzhang [Azure MVP](zsygz@hotmail.com) 
# Thessaloniki.net Meetup Global Azure 2023


We are happy to announce that we participate in this year Global Azure event.


If you have any questions, or you want to participate with a presentation, you can ask us in the following link:
https://www.meetup.com/thessaloniki-net-meetup/

The detailed program will be available soon.


Organizers: 

* Stratos Kourtzanidis 
* Konstantinos Ziazios 
* Charalampos Karypidis
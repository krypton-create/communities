# Azure Tech Frogs - Global Azure 2023

[![Azure Tech Group Guanajuato Mexico](AzureTechFrogs.png "Visit us here!")](https://linktr.ee/azuretechfrogs)

We are an Azure Tech Group from Guanajuato, Mexico. A community that empowers students and professionals with technology.

Global Azure is by the community for the community. In this 2023 edition, we are organizing a **hybrid event with online sessions but also live sessions in León Guanajuato**.

* 📅May, 11-13 2023
* 🏠Location: TBD
* 🎫Get your FREE ticket - [https://www.eventbrite.com.mx/e/global-azure-2023-tickets-595462352927](https://www.eventbrite.com.mx/e/global-azure-2023-tickets-595462352927)
* 🎙️Call for speakers - [https://sessionize.com/atf-global-azure](https://sessionize.com/atf-global-azure)
* 💶Sponsors - We are looking for sponsors. Reach out to the organization team at mlsa-gto@hotmail.com

If you have any questions, feedback or thoughts, please reach out to the community organizers:
* [Contact us](https://linktr.ee/azuretechfrogs)
# Global Azure Bootcamp 2023 - Philippines

[![Global Azure Bootcamp 2023 - Philippines](CloudExpertsGroup.png "Global Azure Bootcamp 2023 - Philippines registration")](https://www.eventbrite.com/e/global-ai-bootcamp-philippines-2023-tickets-531771602177)

Join us 4 March 2023 for a FREE Online event to inspire, learn and deep dive into AI world and technologies.

In this event, we will be inviting experts and MVPs across the globe to present technical sessions on AI and Machine learning with workshops and demonstration.

The Global AI Bootcamp is a series of free one-day events organized across the world by local communities that are passionate about artificial intelligence on Microsoft Azure.
-------------------------------------------------

Hosted by [Cloud Experts Group and .NET Girl](https://www.facebook.com/groups/CloudExpertsGroup).

All our events are free for all attendees. We are committed to your privacy, and your data will never be shared.
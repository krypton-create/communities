# Global Azure Bootcamp 2023 - Pune

[![Global Azure Bootcamp 2023 - Pune](punetechcommunity.png "Global Azure Bootcamp 2023 - Pune registration")](https://www.meetup.com/Pune-Tech-Community/events/285099113/)

We are calling all Azure enthusiasts to come and join us, where we share our expertise and experience.
-------------------------------------------------

Hosted by [Pune Tech Community](https://www.meetup.com/Pune-Tech-Community/).

All our events are free for all attendees. We are committed to your privacy, and your data will never be shared.
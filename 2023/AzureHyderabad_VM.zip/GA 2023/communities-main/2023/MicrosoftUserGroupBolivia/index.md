# Bienvenidos a Global Azure 2023, organizado por MUG Bolivia.

![MUG Bolivia](mugbo.png)

¡Qué tal! Estamos muy emocionados de traer nuevamente Global Azure en su segunda edición en nuestra comunidad [Microsoft User Group Bolivia](https://linktr.ee/microsoftusergroup.bo)

Queremos invitarte, sin importar tu región o país, a que seas parte de este increíble evento junto a nosotros. Será completamente gratuito y en línea. Así que no te lo pierdes, te esperamos los días 11, 12 y 13 de mayo :D

Puedes registrarte en el siguiente link: https://bit.ly/MUGGlobalAzure

Síguenos en redes como Microsoft User Group Bolivia, nos vemos pronto :D

## Microsoft User Group Bolivia

Somos una comunidad de aficionados por la tecnología y distintas herramientas que faciliten su manejo. Nuestra misión es difundir el aprendizaje a todas las personas sin importar su nacionalidad o nivel de conocimiento. No importa si sabes o no, ¡este es un espacio para aprender juntos!

En nuestro canal de YouTube podrás encontrar eventos con temas muy interesantes grabados. También difundimos contenido en redes sociales. Tenemos muchos proyectos futuros en proceso, ¿te gustaría ser parte de ellos?...
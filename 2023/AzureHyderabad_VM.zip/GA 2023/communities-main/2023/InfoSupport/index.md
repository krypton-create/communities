# Global Azure @ Info Support

Join us in-person at Info Support where we will be diving into the world of Microsoft Azure.

In this event, we have three expert speakers lined up to share their knowledge and insights on different aspects of Azure:

- Tom van den Berg: Continuous validation, getting grip on your non-functionals
- Michaël Hompus: Harnessing Open Source Power: Azure Simplifies Your Open Source Adventure
- Sander Molenkamp: Exploring Pulumi: The Modern Infrastructure as Code Solution

Sign up at https://www.infosupport.com/resources/global-azure-2023/
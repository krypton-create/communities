[![Sri Lankan Tech Community](sltc.png "Sri Lankan Tech Community")](https://www.sltechcommunity.lk/)

To build up a resourceful information technology community (where everyone has equal access to essential advanced Information Technology).

[You can also sign up to our meetup page and get notified about all our future events!](https://www.sltechcommunity.lk/)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Viknaraj Manogararajah [Microsoft MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5003394) [@viknaraj](https://twitter.com/viknaraj)
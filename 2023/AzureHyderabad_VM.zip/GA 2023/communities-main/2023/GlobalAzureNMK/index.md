Welcome to the first Global Azure (Bootcamp) 2023 in Skopje, North Macedonia

We are excited to announce that two Microsoft focused communities, Macedonian .Net Community and Macedonian IT Pro User Group joined forces to organize this community event in Skopje.

Global Azure is from the community, for the community. During this global event, communities worldwide will be organizing local editions, and on the 11th of May 2023 it will be organized for the first time in Skopje, North Macedonia

Planning for the schedule and agenda is still underway, and will be announced and updated as we go. We are considering a 3 to 4 hours event in the afternoon, covering a broad range of Azure topics.

At the moment there is Call for Speakers opened for this local event, and all interested experts can apply on the following [link](https://sessionize.com/global-azure-north-macedonia-2023/). 
If you have any questions, feedback or thoughts, please get in touch with the community, please use our [page](https://www.facebook.com/mkdotnet) or contact us on the [e-mail](mailto:glazuremk@mkdot.net).

Follow us on:
[Facebook](https://www.facebook.com/mkdotnet)
[LinkedIn](https://www.linkedin.com/company/macedonian-net-community/)
[Twitter](https://twitter.com/mkdotnet)
[Instagram](https://www.instagram.com/macedonian.net.community/)
# Perth Azure User Group - Global Azure 2023
 
With Covid-19 now in the past enough for us to hold in person events, this year we wanted to bring back Global Azure to our wonderful Perth community.

Global Azure is from the community, for the community. 

During this global event, communities worldwide will be organising local editions, like this one for Perth.

Planning for the day is still underway, and our schedule will be updated as we go. 

We are looking at holding 2 evening events on Thursday and Friday, and an externded event with lunch included on Saturday to really get that Azure vibe going again.

More details will follow via our [Meetup page](https://www.meetup.com/perthazug/).

If you have any questions, feedback or thoughts, please get in touch with the community [leadership team](https://www.meetup.com/perthazug/members/?op=leaders).
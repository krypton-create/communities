# Global Azure Bootcamp 2023 - Boston Azure Edition

The idea is to show up for a full day of hands-on Azure learning.

More details to come.

You can find the organizers on Twitter:

   * Veronika Kolesnikova [@veronika_dev1](https://twitter.com/veronika_dev1)
   * Jason Haley [@haleyjason](https://twitter.com/haleyjason)
   * Bill Wilder [@codingoutloud](https://twitter.com/codingoutloud)

You can find the group on Twitter [@bostonazure](https://twitter.com/bostonazure) &amp; Youtube [youtube.com/bostonazure](https://www.youtube.com/bostonazure)

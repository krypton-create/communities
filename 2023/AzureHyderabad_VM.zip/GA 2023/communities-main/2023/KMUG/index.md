[![K-MUG](k-mug.png "K-MUG")](https://k-mug.net/)

K-MUG aka Kerala Microsoft Users Group - Our mission is to Learn, Build Contacts & Socialize

[You can also visit our events page and learn and attend future events!](https://k-mug.net/events)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Anuraj P [Microsoft MVP](https://mvp.microsoft.com/en-us/PublicProfile/5002040) [@anuraj](https://twitter.com/anuraj)
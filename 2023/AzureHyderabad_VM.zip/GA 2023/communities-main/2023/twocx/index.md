# Azure Day by TwoCX

TwoCX is a leading provider of end-to-end product development services, where cloud technology plays a vital role. TwoCX is owned and operated by Pixelon Studios Limited, a Microsoft Partner company. To further support and engage with our community, we regularly organize events that focus on the latest advancements and best practices in cloud development, especially Microsoft Azure.


If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Malak Zia Nasir [LinkedIn](https://linkedin.com/in/malakzia)
* Bilal Khan [Email](mailto:i-bilal@two.cx)

Interested in joining our community? Write to Malak Zia. [Click here](mailto:malakzia@pixelonstudios.com)

We are arranging the event at TwoCX Swat office.

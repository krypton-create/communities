# Global Azure 2023 - Campinas-SP

Gostaria de conhecer mais sobre o Azure e os diversos serviços oferecidos pela plataforma de cloud computing da Microsoft? Não deixem de acompanhar **edição 2023** do **Global Azure** em **Campinas-SP**, um dos maiores eventos do mundo sobre nuvem e promovido por comunidades técnicas.

Ficou interessado(a)? Faça sua inscrição no link a seguir (**Sympla** - inclui informações gerais do evento) para garantir sua presença e não deixe de indicar o evento para amigas, amigos e colegas de trabalho:

**https://bit.ly/global-azure-cps-2023**

Local: Auditório da Venturus - Estrada Giuseppina Vianelli di Napolli, 1185 - Polo II de Alta Tecnologia - Campinas - SP - CEP: 13086-530.

Este evento é uma iniciativa promovida pela comunidade [**Campinas .NET**](https://www.meetup.com/campinasdotnet/), contando com o apoio dos grupos [**.NET SP**](https://www.meetup.com/dotnet-Sao-Paulo/) e [**Azure Talks**](https://www.meetup.com/azure-talks/).

** A grade com as palestras está em definição e será divulgada em breve!

Para submeter uma proposta de apresentação/palestra utilize este [**link**](https://sessionize.com/global-azure-2023-campinas-sp/).
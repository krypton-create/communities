# Microsoft User Group Perú - Global Azure Perú
  
Esta edición del Global Azure es organizada por el Microsoft User Group Perú, y como todos los años, ofrecemos un espacio para compartir las novedades y mejores practicas para el uso de Azure.

En este momento podemos comentar que ya contamos con una sede presencial, donde podamos compartir con la comunidad, la agenda sera publicada en breve.

Reserve su lugar a través de nuestra [página de Meetup](https://www.meetup.com/es-ES/msperu/events/291544096/).

La comunidad Microsoft User Group Perú, se enfoca en el aprendizaje y el intercambio de información sobre el movimiento Microsoft (Infraestructura, DevOps, Dev, Cloud, DBA) & Open Source en Azure - cultura, prácticas y herramientas.

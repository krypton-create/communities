
Global Azure Bootcamp 2023 New York City Metro Area
===
Welcome to Global Azure Bootcamp 2023 New York City Metro Area!

The New York City event will be an afternoon and evening of learning with fantastic speakers all from your local Microsoft FTE, Microsoft MVP, influencer and SME community.

The event will take place on Thursday, May 11th from 2pm EST to 8pm EST at the Microsoft New York City Reactor at 11 Times Square.

Registration is now open on the Microsoft Reactor site:

[Registration](https://reactor.microsoft.com/en-us/reactor/events/19211/)

If you have any questions, feedback or thoughts, please reach out to the Community organizer:

* Diana Torres Viasus [Cloud and Datacenter Management MVP](https://mvp.microsoft.com/en-us/PublicProfile/5001193)
* Eric Woodruff [Security MVP](https://mvp.microsoft.com/en-us/PublicProfile/5005105)

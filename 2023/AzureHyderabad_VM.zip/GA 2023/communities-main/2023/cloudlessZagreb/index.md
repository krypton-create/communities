# Global Azure Zagreb by Cloudless Zagreb

On May 12th, 2023, we will finally meet in person after a long time, and learn something useful while enjoying some bbq and drinks.


Formerly known as Serverless Zagreb. After two years of inactivity due to mostly COVID-19, we're back with a broader scope and hope to gather people wanting to learn about various cloud solutions, and share their experience.

A group about everything cloud. We'll be covering all the cloud vendors, multi-cloud solutions, hybrid solutions, you name it.

The aim is to deliver useful how-to talks, and experiences "from the trenches" rather than "what's new" talks which you can already see online.
Hopefully you'll join us, learn something useful, share something useful, grab a beer and continue discussing the evolution in how we think about and use infrastructure.


You can reach the organizers and get more info at:
* https://www.meetup.com/Cloudless-Zagreb/

More details coming soon!
# Bienvenidos a Global Azure San Pedro Sula 2023, organizado por la comunidad DevTeam504.

![DevTeam504](devteam504.png)

Te invitamos a la primera edición de Global Azure presencial en la ciudad de San Pedro Sula organizada por la comunidad hondureña [DevTeam504](https://www.meetup.com/es/devteam504)

El evento se realizará el sábado 27 de mayo.

Puedes registrarte en el siguiente link: https://www.meetup.com/es/devteam504/events/292941791/

Búscanos y síguenos en redes como DevTeam504, nos vemos pronto :D

## DevTeam504

Somos una comunidad catracha de tecnología dirigida por desarrolladores de software apasionados por la enseñanza.
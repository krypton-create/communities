We are excited to bring back in-person events and host Global Azure Day 2023 for the Wellington, NZ community

Global Azure is from the community, for the community. During this global event, communities worldwide will be organising local editions and we are organising one for Wellington, New Zealand

Planning for the day is still underway, and our schedule will be updated as we go. We are considering holding a full day event covering a broad range of Azure topics.

More details will follow via our [Meetup page](https://www.meetup.com/wellington-data-management-and-analytics-meetup/events/291994816/). 

If you have any questions, feedback or thoughts, please get in touch with the community [leadership team](https://www.meetup.com/wellington-data-management-and-analytics-meetup/members/?op=leaders).

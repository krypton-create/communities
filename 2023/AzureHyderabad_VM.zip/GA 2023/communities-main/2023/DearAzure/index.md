# Global Azure Bootcamp Aamchi Mumbai 2023

Welcome to Aamchi Mumbai Global Azure Bootcamp 2023!

![Dear Azure](https://raw.githubusercontent.com/globalazure/communities/main/2023/DearAzure/dearazure.png)

We're excited to be hosting an event at Mumbai [Event Page](https://www.eventbrite.com/o/dear-azure-az-india-by-kasam-shaikh-18178264307)!

If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Kasam Shaikh [Microsoft MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5004703) [@KasamShaikh](https://twitter.com/KasamShaikh)
* Abdul Rasheed Feroz Khan [Microsoft MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5002112) [@TechFero](https://twitter.com/TechFero)
* Saineshwar Begari [Microsoft MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5003160) [@saihacksoft](https://twitter.com/saihacksoft)



# TheAzWay - Global Azure Bootcamp 2023
 
We are excited to host Global Azure Bootcamp 2023 for the Dublin area.

Global Azure is from the community, for the community. During this global event, communities worldwide will organize local editions, like this one for the Dublin region.

Planning for the day is still underway, and our schedule will be updated. We are considering hosting a full day event with loads of Azure awesomeness for descision makers and professionals. If you are interested in sharing your knowledge with the community, please submit your session at our [user groups sessionize](https://sessionize.com/gab-dublin/).

More details will follow via our [Website](https://theazway.com/global-Azure) 

If you have any questions, feedback, thoughts, sponsorship, joining organizing team please contact directly  [Contact](https://theazway.com/tushar-profile/).
# AzureHeads

Welcome to Azureheads!
A group of people obsessed with the possibilities of cloud computing and Microsoft's cloud offering, Microsoft Azure! A place to share knowledge, ask questions and meet people with a common focus on cloud technologies.

For more info about the event please visit the following link:
https://global-azure-athens-2023.azurewebsites.net 

### If you want to join our community please reach out on:
* https://www.meetup.com/azureheads/
* https://www.azureheads.gr/
* https://social.azureheads.gr/

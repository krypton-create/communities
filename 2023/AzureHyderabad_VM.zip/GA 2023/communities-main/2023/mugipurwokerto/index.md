Global Azure Indonesia 2023
===========================

Join our Community: https://www.meetup.com/mugi-purwokerto/events/292076194/

Welcome to Global Azure Indonesia 2022!
All around the world user groups and communities want to learn about Azure and Cloud Computing! On May 13, 2023, all communities will come together once again in the nineth great Global Azure Bootcamp event!
This event will be a day of learning and fantastic speakers all from your local Microsoft MVP community! If you are using or considering Microsoft Azure technology and want to learn more about all the great new things you can do - then this is the event for you!


If you have any questions, feedback or thoughts, please reach out to the Community organizer:

* Agus Suparno [AI MVP](https://mugipurwokerto.or.id) 

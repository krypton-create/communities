# DevHub

DevHub is a developer-friendly community with a focus on "Building Nex-Gen Developers". DevHub also provides Career Mentorship, Structured Roadmaps and Virtual internship opportunities. To provide value and strengthen our bond with the community, we host events focused on the latest technologies such as cloud development, machine learning, and AI using Microsoft Azure.  During Global Azure 2023, we will be hosting a physical event that will be focused on Microsoft Azure and Machine Learning.

<br>

Want To Be Speaker For Our Event? **Feel Free To Ping!**

**Abdul Raheem** [LinkedIn](https://www.linkedin.com/in/xfarooqi/)

<br>

🗓️ Event Detail:

**Day:** 11 May 2023

**Time:** 9:00 To 11 AM (Pakistan Standard Time)

**Venue:** C1 COMSATS University, Sahiwal Campus

[Follow To Get Future Updates](https://linktr.ee/devhub_)

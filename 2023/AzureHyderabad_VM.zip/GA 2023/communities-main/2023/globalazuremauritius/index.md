# Global Azure Mauritius 2023

![azug logo][2]

## What

We are back with the second edition of the Global Azure that we will be hosting in Mauritius !

Join us on the 13th May to discover the numerous sessions we have planned for you ;)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

    isubratty@studentambassadors.com
    ouweshseeroo@studentambassadors.com

    Other contact details available on facebook @GlobalAzureMauritius

    More details soon!



## Links

[Facebook][1]  



[1]: https://www.facebook.com/GlobalAzureMauritius
[2]: globalazuremauritius.jpg

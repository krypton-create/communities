**Bienvenue au Microsoft Tech Group Strasbourg**

Le MTG:Strasbourg est une communauté de plus de 10 ans, autour des technologies Microsoft, Azure et .Net.
Le MTG:Strasbourg est aussi memebre de l'association MTG:France qui regroupe les communauté Microsoft en France.

Retrouvez toutes les informations concernant le Global Azure 2023 et nos activités plus généralement sur nos réseaux :
* [LinkedIn](https://www.linkedin.com/company/87242272)
* [Meetup](https://www.meetup.com/fr-FR/mtgstrasbourg)
* [Twitter](https://mobile.twitter.com/MTG_Strasbourg)

**Welcome to the Microsoft Tech Group Strasbourg**

The MTG:Strasbourg is an nearly 10 years old Microsoft, Azure and .Net community in Strasbourg eastern France.
The MTG:Strasbourg is also a fouding member of the MTG:France, the french association of the Microsoft and .Net communities.

You can find everything MTG:Strasbourg related on our social network pages.

# Global Azure 2023 Warsaw Edition

![Global Azure 2023 Warsaw Edition](GlobalAzure2023WarsawWhite500x500.png)

We're excited to be hosting an event at [Global Azure 2023 Warsaw Edition](https://globalazurewarsaw.net/)!

This event will contain two parts - online with a few different great speeches and onsite workshops about Bicep. More information you can find in the above landing page!


Global Azure Bootcamp Singapore 2023 
===

Join our Community: https://www.meetup.com/mssgug/events/291424203/

Welcome to Global Azure Bootcamp 2023!
All around the world user groups and communities want to learn about Azure and Cloud Computing! On May 13, 2023, all communities will come together once again in the eighth great Global Azure Bootcamp event!
Each community will organize their own one day deep dive class on Azure the way they see fit and how it works for their members. The result is that thousands of people get to learn about Azure and join together online under the social hashtag #GlobalAzure! The Global Azure Singapore 2023 event will be a day of learning and fantastic speakers all from your local Microsoft MVP community! If you are using or considering Microsoft Azure technology and want to learn more about all the great new things you can do - then this is the event for you!

This will be the 11th edition of Global Azure Bootcamp in Singapore. After couple of years of virtual events during the COVID-19 pandemic, we are excited to be back in person. We look forward to the vibrant community members to join us on this fantastic day.

The [Call for Speakers is open](https://sessionize.com/global-azure-bootcamp-singapore-2023/). Selection will happen on an ongoing basis. Don't wait to the last day to submit your sessions!!! 

Resume information:
* 📅May, 13 2023
* 🏠Microsoft Singapore, 183 Cecil Street, Singapore 069547
* 🎙️Call for speakers - [https://sessionize.com/global-azure-bootcamp-singapore-2023/](https://sessionize.com/global-azure-bootcamp-singapore-2023/)
* 💶Sponsors - We are looking for sponsors. Reach out to the organizing team.



If you have any questions, feedback or thoughts, please reach out to the Community organizer:

* Nilesh Gule [Azure MVP](nileshgule@outlook.com) 
* Sakthis Kumar [Azure MVP](sakthis@sakthis.net)
* Senthamil Selvan [Azure MVP](altfo@hotmail.com)
* Asif Waquar [Azure MVP](asifwaquar2012@gmail.com)

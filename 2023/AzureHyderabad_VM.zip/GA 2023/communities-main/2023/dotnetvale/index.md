# Dotnet Vale - Global Azure BootCamp 2023

Estamos felizes em anunciar o Retorno do Global Azure BootCamp em São José dos Campos em 2023!!!

O Global Azure é um evento realizado pela comunidade, para a comunidade. Teremos um dia todo com diversos conteúdos sobre Azure para que possamos aprender mais sobre o assunto.


A nossa agenda ainda não está definida, mas se você gostaria de apresentar algum tema conosco, não deixe de submeter sua palestra para avaliação no [Sessionize](https://sessionize.com/global-azure-bootcamp-sjcampos/)

Você pode saber mais sobre o evento, atravéz do nosso [Meetup](https://www.meetup.com/pt-BR/net-vale/) e também pelo [Sympla](https://www.sympla.com.br/evento/global-azure-bootcamp/1894910) para se inscrever.

Esperamos você lá!
# Global Azure Angola by Data & Azure Community Luanda 

[![Data & Azure Community Luanda](Logo%20Global%20Azure%20Angola.png "Visit us here!")](https://www.globalazure.ao/)

Global Azure Angola is a community event organized by the Data & Azure Community Luanda.
All around the world user groups and communities are sharing knowledge to professionals that want to learn more about Microsoft Azure and Cloud Computing!
On May 13, 2023, we will gather for the first time in Angola to bring you the Global Azure event! Data & Azure Community Luanda brings a world-class event day on Microsoft Azure. Join us online and don't forget to use the social hashtags #GlobalAzureAO and #GlobalAzure!


The [Call for Speakers is open](https://sessionize.com/global-azure-angola-2023/). Selection will happen on an ongoing basis. Don't wait to the last day to submit your sessions!!! 


Resume information:
* 📅May, 13 2023
* 🏠Microsoft Luanda
* 🎫Get your FREE ticket - [https://www.globalazure.ao/](https://www.globalazure.ao/)
* 🎙️Call for speakers - [https://sessionize.com/global-azure-angola-2023](https://sessionize.com/global-azure-angola-2023/)
* 💶Sponsors - We are looking for sponsors. Reach out to the organization team at [https://www.linkedin.com/groups/9302919/](https://www.linkedin.com/groups/9302919/)

If you have any questions, feedback or thoughts, please reach out to the community organizers at:
* https://www.linkedin.com/groups/9302919/

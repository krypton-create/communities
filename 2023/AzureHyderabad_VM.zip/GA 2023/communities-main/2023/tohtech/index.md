# Global Azure 2023 - Toh Tech Community

[![Global Azure Bootcamp 2023 - Toh Tech Community](tohtech.png "Global Azure 2023 - Toh Tech Community")](https://beacons.ai/tohtech)

Join us at *Global Azure* hosted by the Toh Tech Community. This is a hybrid event, we will have online sessions and in-person sessions in Mérida, Yucatán.

🎟️ Get your ticket [here](https://GlobalAzure23-TohTech.eventbrite.com.mx).

✉️ If you are interested in being a speaker, [send your proposal](https://sessionize.com/GlobalAzure23-TohTech/).

💰 We are looking for sponsors. If you would like to support the event, contact us at toh.tech@outlook.com.

### About us

We are a community in the southeast of Mexico. We organize events that encourage interest in science and technology.

Follow us on [social media](https://beacons.ai/tohtech) for updates.
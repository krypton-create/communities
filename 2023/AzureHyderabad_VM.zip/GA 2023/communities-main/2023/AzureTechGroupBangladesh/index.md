We are excited to organize some awesome online sessions and host Global Azure Day 2023 for the Azure Tech Group Bangladesh Community

Global Azure is from the community, for the community. During this global event, communities worldwide will be organising local editions and we are organising one for Bangladesh

Planning for the day is still underway, and our schedule will be updated as we go. We are considering holding a full day event covering a broad range of Azure topics.

More details will follow via our [Facebook Group](https://www.facebook.com/groups/1770787936632620). 

If you have any questions, feedback or thoughts, please get in touch with the  community leader Shahriyar Al Mustakim Mitul at mitulshahriyar@gmail.com

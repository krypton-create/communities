# Community title

![Community title](template.png)

We're excited to be hosting an event at [Community title](https://globalazure.net/this-is-just-a-sample-link/)!

Here you put any markdown content which describes your event location, and what you will be doing at your event. Get creative and tell your own story, list your agenda, speakers, and anything else that seems relevant to you! Please feel free to be inspired by all the community submissions at [GlobalAzure.net/communities](http://globalazure.net/communities)

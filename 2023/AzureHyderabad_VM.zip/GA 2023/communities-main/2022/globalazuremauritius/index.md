# Global Azure Mauritius

[![Global Azure Mauritius Logo](GlobalAzureMauritius.png "Visit us here!")](https://www.facebook.com/GlobalAzureMauritius/)

Global Azure Mauritius is a community organizing the Global Azure event in Mauritius, local partners being one of the most important technical forums about Microsoft's Cloud Computing platform.

In this 2022 edition, we are preparing a **hybrid event with online sessions but also live sessions at Middlesex University Mauritius**. 

We hope this is the beginning of the end of this pandemic! :)

If you have any questions, feedback or thoughts, please reach out to the community organizers:
* isubratty@studentambassadors.com
* ouweshseeroo@studentambassadors.com
* Other contact details available on facebook GlobalAzureMauritius

More details soon!
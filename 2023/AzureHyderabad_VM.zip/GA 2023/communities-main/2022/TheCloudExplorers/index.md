# The Cloud Explorers
Watch this for updates on Global Azure Bootcamp.
    
Join us at [https://www.eventbrite.com/e/global-azure-2022-netherlands-tickets-321242363557](https://www.eventbrite.com/e/global-azure-2022-netherlands-tickets-321242363557).

[https://github.com/thecloudexplorers](https://github.com/thecloudexplorers)
# Microsoft Learn Student Ambassadors - Bolivia

Please visit and join our [group](https://mango-pebble-0d4094a10.1.azurestaticapps.net/).

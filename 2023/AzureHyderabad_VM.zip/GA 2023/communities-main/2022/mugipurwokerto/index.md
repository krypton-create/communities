Global Azure Indonesia 2022
===

Join our Community: https://bit.ly/globalazure2022

Welcome to Global Azure Indonesia 2022!
All around the world user groups and communities want to learn about Azure and Cloud Computing! On May 7, 2022, all communities will come together once again in the eighth great Global Azure Bootcamp event!
Each community will organize their own one day deep dive class on Azure the way they see fit and how it works for their members. The result is that thousands of people get to learn about Azure and join together online under the social hashtag #GlobalAzure! The Mississauga event will be a day of learning and fantastic speakers all from your local Microsoft MVP community! If you are using or considering Microsoft Azure technology and want to learn more about all the great new things you can do - then this is the event for you!


If you have any questions, feedback or thoughts, please reach out to the Community organizer:

* Agus Suparno [AI MVP](https://mugipurwokerto.or.id) 

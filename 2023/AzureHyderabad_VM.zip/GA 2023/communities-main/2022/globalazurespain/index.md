# Global Azure Spain

[![Global Azure Spain Logo](GlobalAzure2022LiveFromSpain-250.png "Visit us here!")](https://globalazure.es/)

Global Azure Spain is a community organizing the Global Azure event in Spain, sponsored by Microsoft and local partners being one of the most important technical forums about Microsoft's Cloud Computing platform.

In this 2022 edition, we are preparing a **hybrid event with online sessions but also live sessions in Madrid and Barcelona**. The [Call for Speakers is already open and is for both virtual and physical sessions](https://sessionize.com/global-azure-2022-spain), so please specify your preference when submitting your proposals. We will try to respect this preference as much as possible, taking into account the capacity of the spaces provided for the physical events.

We hope this is the beginning of the end of this pandemic! :)

If you have any questions, feedback or thoughts, please reach out to the community organizers:
* hello@globalazure.es 
* Other contact details available on https://globalazure.es/

More details soon!
# Global Azure Chile

[![Global Azure Chile](globalazurechile.png "Join meetup here")](https://www.meetup.com/es-ES/cloud-smart/)

Our community operates in Chile for all Latin America. We strive to run meetups, and to invite interesting speakers with exciting Azure and cloud topics. We are set up to live stream and you can visit our events to view them live and socialize with the other members.

# Global Azure Bootcamp BH | CodeFC & SQLBH

Visit our websites at https://youtube.com/codefc and https://www.meetup.com/pt-BR/SQL-BH/


If you have any questions, feedback or thoughts, please reach out to the community organizers:

- Osanam Giordane [Azure MVP](https://mvp.microsoft.com/pt-br/PublicProfile/5001893) [@osanam-giordane](https://www.linkedin.com/in/osanam-giordane/)
- Albert Tanure [Developer MVP](https://mvp.microsoft.com/pt-br/PublicProfile/5002952) [@albert-tanure](https://www.linkedin.com/in/albert-tanure/)
- Sulamita Dantas [Data MVP](https://mvp.microsoft.com/pt-br/PublicProfile/5003100) [@sulamitadantas](https://www.linkedin.com/in/sulamitadantas/)
- Leonardo Fonseca [Data MVP](https://mvp.microsoft.com/pt-br/PublicProfile/5004768) [@leofb](https://www.linkedin.com/in/leofb/)

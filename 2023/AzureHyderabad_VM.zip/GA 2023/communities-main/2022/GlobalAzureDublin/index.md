[![Dublin Cloud User Group](clean_485827658.jpeg "Dublin Cloud User Group")](https://www.dublinclouduser.group)

This is a group for all topics related to Azure and Microsoft 365.
From hands-on workshops to technical talks and events.

[You can also sign up to our meetup page and get notified about all our future events!](https://www.meetup.com/Dublin-Cloud-User-Group/)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Rob Atkinson: [@futurefiles](https://twitter.com/futurefiles)

Global Azure 2022 Across the Pond in North America!
===

Consider speaking as part of our new community called Come Cloud With Us: https://sessionize.com/come-cloud-with-us/
Please do also give us a follow on Twitter at: https://twitter.com/comecloudwithus

All around the world, user groups and communities want to learn about Azure and Cloud Computing! On May 5th through the 7th, 2022, all communities will come together once again to participate in this incredible by the community, for the community #GlobalAzure event!
We're livestreaming our session to YouTube this year, and are excited to bring this content to you, wherever you may be!


For any questions, thoughts, or feedback - please reach out to one of our community organizers:

* Abdul Kazi [AZURE ARCHITECT | MCT | BLOGGER | MENTOR | SPEAKER | LEARNER](https://twitter.com/abdulkazi)
* Chris Gill [CLOUD AND MODERN WORKPLACE ADVOCATE | LEARN-IT-ALL | BLOGGER | MENTOR | SPEAKER | DIVERSITY & INCLUSION ALLY](https://twitter.com/cgill)

# Global Azure BiH by MSCommunity BiH

[![MS Community BiH](mscommunitybih.png "Visit us here!")](https://www.meetup.com/MS-Community-BiH/events/270102902/)

Global Azure BiH is a community event organized by the MS Community BiH UG.
All around the world user groups and communities are sharing knowledge to professionals that want to learn more about Microsoft Azure and Cloud Computing!
On May 6, 2022, we will come together to once again bring the Global Azure event! And yes, we are doing it in-person this year! Don't forget to use the social hashtag #GlobalAzure!


If you have any questions, feedback or thoughts, please reach out to the community organizers at:
* http://www.mscommunity.ba/

More details soon!

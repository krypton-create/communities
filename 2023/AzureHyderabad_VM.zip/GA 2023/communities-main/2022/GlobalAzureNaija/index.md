<h2> Global Azure Nigeria </h2>
<img src="https://github.com/Paulooma/communities/blob/main/2022/GlobalAzureNaija/AzureNigeriaLogo.png" alt="The Nigeria Azure Community Logo">
<b> Global Azure Nigeria </b> is community of Nigerian cloud professional coming together to learn and share ideas, This year Global Azure is the 4th consecutive events, sponsored by Microsoft and local partners.

We are currently preparing for the event and the <a href="https://sessionize.com/global-azure-lagos-nigeria-2022/">Call for Speaker is available for a Physical and virtual Sessions</a>.

If any questions; reach out to us

<a href="info@azurenigeria.community">info@azurenigeria.community</a><br>
<a href="azurenigeria.community">azurenigeria.community</a>

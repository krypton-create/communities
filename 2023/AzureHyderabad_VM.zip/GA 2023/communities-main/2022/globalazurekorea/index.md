# Global Azure Vurtial 2022 on Korea!

[![슬기로운 Azure생활](globalazurevirtualkorea.png "Visit us here!")](https://helloailab.notion.site/Global-Azure-Korea-2022-9e4482f80da64def9532b942e5fd826c)

Global Azure Virtual 2022 on Korea is a community event hosted by the Korea Azure User Group and 슬기로운 Azure생활.
User groups and communities around the world are sharing their knowledge with experts who want to learn more about Microsoft Azure and cloud computing!
On May 7, 2022, the Global Azure event will be held! And yes, we will be doing it ourselves this year! Don't forget to use the social hashtag #GlobalAzure!

More details soon!

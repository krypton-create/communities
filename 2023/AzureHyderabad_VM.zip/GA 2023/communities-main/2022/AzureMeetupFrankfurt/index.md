# Azure Meetup Frankfurt

Please visit https://www.meetup.com/Azure-Meetup-Frankfurt/events/284308661/


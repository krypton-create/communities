[![MicrosoftUCuencaCommunity](logo.png "MicrosoftUCuencaCommunity")](https://microsoft.ucuenca.edu.ec/)

Microsoft UCuenca es una comunidad universitaria, cuya misión es empoderar a docentes y estudiantes de la Universidad de Cuenca a desarrollar su máximo potencial para juntos lograr más. 

Conoce más en: 

[YouTube Channel](https://www.youtube.com/channel/UCQka8dOZy5FGZGdPGSta4yQ)

[FB Page](https://www.facebook.com/MicrosoftUCuenca)

[Instagram](https://www.instagram.com/microsoftucuenca/)

[Twitter](https://twitter.com/microsoftUC)






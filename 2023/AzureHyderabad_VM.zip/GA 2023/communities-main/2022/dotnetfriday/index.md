# DotNetFriday

Visit our website at https://dotnetfriday.nl

![DotNetFriday](dnf.png)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

- Eduard Keilholz [Azure MVP](https://mvp.microsoft.com/en-us/PublicProfile/5003924) [@nikneem](https://twitter.com/ed_dotnet)
- Annejan Barelds [@BareldsA](https://twitter.com/BareldsA)

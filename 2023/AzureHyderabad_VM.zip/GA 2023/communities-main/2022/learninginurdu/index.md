[![LearningInUrdu](logo.jpg "LearningInUrdu")](https://learninginurdu.pk/)

This group is producing content mainly in Urdu (local) language. Also It is organizing differnet Microsoft events.

[YouTube Channel](https://www.youtube.com/channel/UCk1JI7ASy1EnzaM0hdVcuAQ)

[FB Page](https://web.facebook.com/LearningInUrduCentre)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Bilal Shahzad [Microsoft MVP/MCT](https://mvp.microsoft.com/en-us/PublicProfile/5002638)


[![Virtual DEV Show](logo.png "Virtual DEV Show")](https://virtualdevshow.com/)

Virtual DEV Show es un Azure Tech Group de Microsoft, con espacios únicos e increíbles para adquirir nuevos conocimientos, compartir con los demás, y conectar entre todos.

El Virtual DEV Show se fundamenta en la misión de Microsoft de empoderar a todas las personas y organizaciones del planeta para lograr más. Aquí puedes ver nuestras redes sociales y página web con recursos y oportunidades para conocer más:

- http://virtualdevshow.com/
- https://twitter.com/VirtualDEVShow
- https://instagram.com/virtualdevshow/
- https://www.youtube.com/channel/UCGy-A0MAdB5lWx7XKCsJgPg
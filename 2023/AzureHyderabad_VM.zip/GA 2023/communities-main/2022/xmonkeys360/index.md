[![XMonkeys360](xm360.png "XMonkeys360")](https://XMonkeys360.com)

The XMonkeys360 Community strongly believes that it has a pivotal role to play in shaping the destiny of our future developers.

[You can also sign up to our meetup page and get notified about all our future events!](https://www.meetup.com/XMonkeys360/)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Anbu Mani [Microsoft MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5002235) [@Anbu_Mani27](https://twitter.com/Anbu_Mani27)
* karthikeyan VK [Microsoft MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5003051) [@karthik3030](https://twitter.com/karthik3030)
* Sathish Nadarajan [Microsoft MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5001930) [@contactsathish](https://twitter.com/contactsathish)
* Logesh Palani [Microsoft MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5004431) [@logeshpalani30](https://twitter.com/logeshpalani30)

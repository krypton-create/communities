
Communauté Azure de Québec
===

# English

Join our Community (it's free and we're fun!): https://meetup.com/azureqc

![Azure Quebec](AzureQuebec.png)

If you have any questions, feedback or thoughts, please reach out to the Community organizers:

* Tidjani Belmansour [Azure MVP](https://mvp.microsoft.com/en-us/PublicProfile/5003457) [@tidjani_b](https://twitter.com/tidjani_b)
* Maxime Coquerel [Azure MVP](https://mvp.microsoft.com/en-us/PublicProfile/5002627) [@zig_max](http://twitter.com/zig_max)



# French

Joignez-vous à notre Communauté (c'est gratuit et on est sympa!):  https://meetup.com/azureqc

![Azure Québec](AzureQuebec.png)

Si vous avez des questions, des commentaires ou des idées, veuillez contacter les organisateurs de la Communauté :

* Tidjani Belmansour [Azure MVP](https://mvp.microsoft.com/en-us/PublicProfile/5003457) [@tidjani_b](https://twitter.com/tidjani_b)
* Maxime Coquerel [Azure MVP](https://mvp.microsoft.com/en-us/PublicProfile/5002627) [@zig_max](http://twitter.com/zig_max)

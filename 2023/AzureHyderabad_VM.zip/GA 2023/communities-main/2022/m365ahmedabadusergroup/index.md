# M365 Ahmedabad User Group
Watch this for updates on Global Azure Bootcamp - Ahmedabad.


Join us at [https://www.meetup.com/m365ahmedabad/](https://www.meetup.com/m365ahmedabad/) to stay up to date.

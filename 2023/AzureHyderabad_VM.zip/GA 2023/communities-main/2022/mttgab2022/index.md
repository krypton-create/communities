[![Microsoft Technical Trainers](mttgab2022.png "Microsoft Technical Trainers")](https://www.microsoft.com/learning/)

We are a global team of Microsoft Technical Trainers - Full-Time Employees, within Microsoft Global Technical Learning (GTL), training customers and partners on the AZ-, SC-, DP- and PL- Microsoft Official Courseware.

[YouTube Channel](https://aka.ms/mtcc)




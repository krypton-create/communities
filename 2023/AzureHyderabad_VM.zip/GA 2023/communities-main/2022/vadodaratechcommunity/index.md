# Global Azure Bootcamp 2022 - Vadodara

Join us at [https://www.meetup.com/vadodara-tech-community/](https://www.meetup.com/vadodara-tech-community/) to stay up to date.

## Global Azure - 2022 : Bengaluru

[Microsoft Azure User Group - Bengaluru)](https://www.meetup.com/Microsoft-Azure-Bangalore/)

Microsoft Azure User Group - Bengaluru has been helping hundreds of developers embark on their journey to Azure by running various events like meetups, conferences, hackathons etc., We are very excited to bring back the Global Azure event 2022 as in person event (most likely - fingerscrossed) in Bengaluru

Join us to learn and spread the joy of Azure
[Meetup Link](https://www.meetup.com/Microsoft-Azure-Bangalore/)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Swaminathan Vetri [Microsoft MVP](https://mvp.microsoft.com/en-us/PublicProfile/5001989) [@svswaminathan](https://twitter.com/svswaminathan)
* Chendrayan V [Microsoft MVP](https://mvp.microsoft.com/en-us/PublicProfile/5000478) [@ChendrayanV](https://twitter.com/chendrayanv)
* Jasjit Chopra [Microsoft MVP](https://mvp.microsoft.com/en-us/PublicProfile/5002906) [@jasjitchopra](https://twitter.com/jasjitchopra)
 
[![ChennaiAzureUserGroup](azchennai.png "ChennaiAzureUserGroup")](https://www.meetup.com/Chennai-Microsoft-Azure-User-Group/)

We are a community-run user group with the goal of learning and sharing our knowledge on cloud computing with the Microsoft Azure cloud platform. Our first meeting was on February 2016 at Microsoft Chennai(India) Office.

[You can also sign up to our meetup page and get notified about all our future events!](https://www.meetup.com/Chennai-Microsoft-Azure-User-Group/)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Karthikeyan VK [Microsoft MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5003051) [@karthik3030](https://twitter.com/karthik3030)
* Anbu Mani [Microsoft MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5002235) [@Anbu_Mani27](https://twitter.com/Anbu_Mani27)
* Dinesh Kumar P [Microsoft MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5004581) [@Dinuswt22](https://twitter.com/Dinuswt22)
 
# Azure Meetup Torino

[![Azure Meetup Torino](AzureMeetupTorino.png "Join Azure Meetup Torino here")](https://www.meetup.com/it-IT/Meetup-Microsoft-Azure-Torino/)

Our community operates in Torino. We strive to run monthly meetups, and to invite interesting speakers with exciting Azure topics. We are set up to live stream and you can visit our events to view them live and socialize with the other members.

[Please pop into our Meetup page and have a look at our community and our activities - and do join us](https://www.meetup.com/it-IT/Meetup-Microsoft-Azure-Torino/)
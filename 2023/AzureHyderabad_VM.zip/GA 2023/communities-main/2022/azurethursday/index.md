[![Azure Thursday logo](logo-azure-thursday.png "Azure Thursday website")](https://www.azurethursday.com)

This is a group for all developers, consultants, architects and IT professionals who want to dive into for them unknown topics related to Azure. Azure Thursday are happening every first Thursday of the month and the format will be different every evening. From hands-on workshops to technical talks.

[You can also sign up to our meetup page and get notified about all our future events!](https://www.meetup.com/nl-NL/Azure-Thursdays/)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Esther Barthel: [@VirtuEs_IT](https://twitter.com/virtuEs_IT)
* Henk Boelman: [@hboelman](https://twitter.com/hboelman) 
* Roelant Dieben: [@RoelantDieben](https://twitter.com/RoelantDieben)
* Stefan Dingemanse: [@SDingemanse](https://twitter.com/SDingemanse)
* Roel van de Grint: [@rvdgrint](https://twitter.com/rvdgrint)
* Luuk Mager: [@luuk_mager](https://twitter.com/luuk_mager)
* Jorrit Meijer: [@JorritMeijer](https://twitter.com/JorritMeijer)
* Sjoukje Zaal: [@SjoukjeZaal](https://twitter.com/SjoukjeZaal)
# Comunidad Xamarin en Español

Please visit and join our [group](https://www.facebook.com/groups/xamarindiplomadoitc).

You can also subscribe to our [channel](https://www.youtube.com/c/ComunidadXamarinenEspa%C3%B1ol/)

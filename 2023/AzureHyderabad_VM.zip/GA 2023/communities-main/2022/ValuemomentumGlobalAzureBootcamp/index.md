# Global Azure Bootcamp 2022 - Valuemomentum

[![ValuemomentumGlobalAzureBootcamp](ValuemomentumGlobalAzureBootcamp.png "Global Azure Bootcamp 2022 - Valuemomentum Registration")](https://www.valuemomentum.com/)

Following the success of organizing three previous Global Azure Bootcamps, ValueMomentum is happy to bring you the fifth edition, the Global Azure 2022.
This event is free and open to everyone across the world who is interested in learning about MS Azure-based technology stack.

We have a line-up of interactive and experiential sessions in which participants will understand and visualize the full gamut of Microsoft Azure technologies. The speakers in the event come with a rich and diverse experience in Microsoft Technology Stack from an end-to-end perspective. 
-------------------------------------------------
Hosted by [Valuemomentum](https://www.valuemomentum.com/), the city's largest OSS community.
You can find us on [Twitter](https://twitter.com/valuemomentum), [Facebook](https://www.facebook.com/ValueMomentum/), [LinkedIn](https://in.linkedin.com/company/valuemomentum), [Instagram](https://www.instagram.com/valuemomentum_inc/?hl=en)] 

All our events are free for all attendees. We are committed to your privacy, and your data will never be shared.

# Cloudgen Verona

Visit our website at https://cloudgen.it

![Cloudgen Verona](Logo-CloudGen.png)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Marco Zamana [AI MVP](https://mvp.microsoft.com/en-us/PublicProfile/5003347) [@marco_zamana](https://twitter.com/marco_zamana)
* Andrea Tosato [Azure MVP](https://mvp.microsoft.com/en-us/PublicProfile/5003336) [@ATosato86](https://twitter.com/ATosato86)

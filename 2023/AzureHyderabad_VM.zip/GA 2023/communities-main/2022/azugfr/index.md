# AZURE USER GROUP FRANCE 

![azugfr logo][3]

## What

AZUG FR - Azure User Group France, French-speaking Microsoft Azure community.
Exchange of technical advice and feedback on Microsoft's cloud computing platform, whether Infrastructure-as-a-Service or Platform-as-a-Service.


## Who

[Want to get to know us][0]?

## Links

[Main website][0]
[Linkedin][1] 
[Twitter][2]  

[0]: https://www.meetup.com/fr-FR/AZUG-FR/
[1]: https://linkedin.com/groups/8315615/
[2]: https://twitter.com/azugfr
[3]: azugfr.png


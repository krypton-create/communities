# Global Azure Stockholm

Not so much a regular community as a couple of people who wanted in on the Global Azure fun!

Event to take place at Microsoft Reactor, Regeringsgatan 59 Stockholm, on the 5th of May, on-prem and live streamed at [Microsoft Reactor YouTube channel](https://aka.ms/globalazursthlm).

## Tickets

Tickets / seat reservation available at [Eventbrite](https://www.eventbrite.com/e/global-azure-bootcamp-2022-stockholm-tickets-269595927677)

## Organizers

If you have any questions, feedback or thoughts, please reach out to the community organizers:

- [Björn Sundling - @Bjompen](https://twitter.com/Bjompen)
- [Simon Wåhlin - @SimonWahlin](https://twitter.com/SimonWahlin)
- [Stefan Ivemo - @StefanIvemo](https://twitter.com/StefanIvemo)

![Global Azure Stockholm](./gasthlm.png)
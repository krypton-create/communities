
Global Azure Bootcamp 2022 Greater Toronto Area
===

Join our Community: https://www.meetup.com/metrotorontoug/events/283781596/

Welcome to Global Azure Bootcamp 2022!
All around the world user groups and communities want to learn about Azure and Cloud Computing! On May 7, 2022, all communities will come together once again in the eighth great Global Azure Bootcamp event!
Each community will organize their own one day deep dive class on Azure the way they see fit and how it works for their members. The result is that thousands of people get to learn about Azure and join together online under the social hashtag #GlobalAzure! The Mississauga event will be a day of learning and fantastic speakers all from your local Microsoft MVP community! If you are using or considering Microsoft Azure technology and want to learn more about all the great new things you can do - then this is the event for you!


If you have any questions, feedback or thoughts, please reach out to the Community organizer:

* Ehsan Eskandari [Azure MVP](https://globalazure.ca/contact-us) 

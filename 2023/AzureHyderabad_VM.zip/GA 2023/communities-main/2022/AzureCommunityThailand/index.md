# Azure Community Thailand

[![Azure Community Thailand](AzureCommunityThailand.png "Visit us here!")](https://www.facebook.com/groups/AzureCommunityThailand)

Azure Community Thailand is a local user group where developers, administrators, and solutions architects in Thailand learn and engage one another on topics related to Azure, Visual Studio, and other Microsoft technologies.

Follow us on Facebook at https://www.facebook.com/groups/AzureCommunityThailand.
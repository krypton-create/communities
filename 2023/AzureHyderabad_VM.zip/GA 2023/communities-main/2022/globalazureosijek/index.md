Global Azure Osijek by IT Pro Community Osijek and IT Pro Community Zagreb
On May 5th, 2022, we will have hybrid event related to Azure platform. Meet, learn, eat and dring together with IT Community and Azure speakers and freaks.

Tradition to move Azure Global camp throuhg Croatia, continue this year. We will be in Osijek, one of exelent IT community town in Slavonije, Easter part of Croatia. 
We will show you what is new in Azure, what can you use and if you will have questions, to answer your questions.

You can reach the organizers and get more info at:

E-mail: itpro-hr@mscommunity.hr
https://www.meetup.com/IT-Pro-User-Group-Zagreb/
More details coming soon!
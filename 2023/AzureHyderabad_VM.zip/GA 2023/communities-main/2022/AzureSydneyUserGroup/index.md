# Azure Sydney User Group - Global Azure Day
 
After a break of more than two years, we are excited to bring back in-person events and host Global Azure Day 2022 for the Sydney community.

Global Azure is from the community, for the community. During this global event, communities worldwide will be organising local editions, like this one for Sydney.

Planning for the day is still underway and our schedule will be updated as we go. We are considering holding a full day multi-track event covering a broad range of Azure topics.

Reserve your spot via our [Meetup page](https://www.meetup.com/Azure-Sydney-User-Group/events/285124514/).
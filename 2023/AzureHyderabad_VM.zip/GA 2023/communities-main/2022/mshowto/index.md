# Global Azure Istanbul

[![MSHOWTO logo](mshowto.png "Visit us here")](https://www.mshowto.org/)

Global Azure 2022 Istanbul is hosted by [MSHOWTO](https://www.mshowto.org/)

Tickets / seat reservation available at [Eventbrite](https://www.eventbrite.com/e/global-azure-istanbul-2022-tickets-313124552967)

![Global Azure Istanbul](gaist.png)
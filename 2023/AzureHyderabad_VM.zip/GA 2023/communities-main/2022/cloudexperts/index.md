# Cloud Experts

Únete a nuestros eventos en: https://www.meetup.com/es/cloudexpertsc


Si tiene preguntas, comentarios o ideas, comuníquese con los organizadores de la comunidad:

- Juan Rafael [MVP Business Applications](https://mvp.microsoft.com/es-es/PublicProfile/5001496) [@jlc_rve](https://twitter.com/jlc_rve/)
- Frank Chambillo [MVP Reconnect](https://mvp.microsoft.com/es-es/PublicProfile/5002079) [@frankchambillo](https://twitter.com/frankchambillo/)

# Override .Net Community

Visit our website at https://www.meetup.com/pt-BR/Override


If you have any questions, feedback or thoughts, please reach out to the community organizers:

- Marcelo Paiva [Azure MVP](https://mvp.microsoft.com/pt-br/PublicProfile/5004192) [@marcelojpaiva](https://www.instagram.com/marcelojpaiva/)
- Rodrigo Kono [Developer MVP](https://mvp.microsoft.com/pt-br/PublicProfile/4020681) [@rodrigo.kono](https://www.instagram.com/rodrigo.kono/)
# Azure Kubernetes User Group Amsterdam

This group is for anyone who is interested in Azure Kubernetes Service.
Meetups/ talks will be focussing on AKS and related tooling. We welcome everyone regardless of the experience and knowledge of that person!

If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Bram van den Klinkenberg: [@BramKlinkenberg](https://twitter.com/BramKlinkenberg)
* Daniel Paulus: [@paulustm](https://twitter.com/PaulusTM)
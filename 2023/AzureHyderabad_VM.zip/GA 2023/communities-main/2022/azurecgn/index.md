# Global Azure Bootcamp Cologne

[![Global Azure Bootcamp Cologne Logo](azurecgn-logo.png "Visit us here!")](https://www.rakoellner.de/global-azure-cgn)

Azure Meetup Cologne is a community organizing the Global Azure event in Cologne, sponsored by local partners being one of the most important technical forums about Microsoft's Cloud Computing platform in Germany.

#GlobalAzure is an international event that takes place in many countries. We are part of the Global Azure event and we seek to spread and generate talks focused on the various areas of Azure and cloud computing for various disciplines such as: web development, artificial intelligence, DevOps, security, infrastructure and much more.
# Global Azure Lima

[![Global Azure Lima](1650315725256.jpg "Join meetup here")](https://www.meetup.com/es/msperu/events/285086738/)

Esta edición del Global Azure es organizada en Lima por el Microsoft User Group Perú, y como todos los años, ofrecemos un espacio para compartir las novedades y mejores practicas para el uso de Azure.

La comunidad Microsoft User Group Perú, se enfoca en el aprendizaje y el intercambio de información sobre el movimiento Microsoft (Infraestructura, DevOps, Dev, Cloud, DBA) & Open Source en Azure - cultura, prácticas y herramientas.

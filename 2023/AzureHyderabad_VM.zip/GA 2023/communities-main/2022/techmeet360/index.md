# TechMeet360

Visit our website at https://www.meetup.com/techmeet360/

![techmeet360](https://www.techmeet360.com/wp-content/uploads/2017/07/techmeet360-logo.png)

If you have any questions, feedback or thoughts, please reach out to the community organizers:

* Kuppurasu Nagaraj [Azure MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5001934) [@kuppurasu360](https://twitter.com/kuppurasu360)
* Suhas Parameshwara [Microsoft MVP] (https://mvp.microsoft.com/en-us/PublicProfile/5004062) [@suhas_paramesh](https://twitter.com/suhas_paramesh)

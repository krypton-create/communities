# Pune User Group
Watch this for updates on Global Azure Bootcamp - Pune.
  
  
Join us at [https://meetup.com/puneusergroup](https://meetup.com/puneusergroup) to stay up to date.
